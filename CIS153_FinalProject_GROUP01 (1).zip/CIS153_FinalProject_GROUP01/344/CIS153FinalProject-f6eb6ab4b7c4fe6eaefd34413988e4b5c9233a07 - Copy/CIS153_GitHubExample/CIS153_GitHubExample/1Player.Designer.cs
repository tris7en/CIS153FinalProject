﻿
namespace CIS153_GitHubExample
{
    partial class _1Player
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_5_6 = new System.Windows.Forms.Button();
            this.btn_5_5 = new System.Windows.Forms.Button();
            this.btn_5_4 = new System.Windows.Forms.Button();
            this.btn_5_3 = new System.Windows.Forms.Button();
            this.btn_5_2 = new System.Windows.Forms.Button();
            this.btn_5_1 = new System.Windows.Forms.Button();
            this.btn_5_0 = new System.Windows.Forms.Button();
            this.btn_4_6 = new System.Windows.Forms.Button();
            this.btn_4_5 = new System.Windows.Forms.Button();
            this.btn_4_4 = new System.Windows.Forms.Button();
            this.btn_4_3 = new System.Windows.Forms.Button();
            this.btn_4_2 = new System.Windows.Forms.Button();
            this.btn_4_1 = new System.Windows.Forms.Button();
            this.btn_4_0 = new System.Windows.Forms.Button();
            this.btn_3_6 = new System.Windows.Forms.Button();
            this.btn_3_5 = new System.Windows.Forms.Button();
            this.btn_3_4 = new System.Windows.Forms.Button();
            this.btn_3_3 = new System.Windows.Forms.Button();
            this.btn_3_2 = new System.Windows.Forms.Button();
            this.btn_3_1 = new System.Windows.Forms.Button();
            this.btn_3_0 = new System.Windows.Forms.Button();
            this.btn_2_6 = new System.Windows.Forms.Button();
            this.btn_2_5 = new System.Windows.Forms.Button();
            this.btn_2_4 = new System.Windows.Forms.Button();
            this.btn_2_3 = new System.Windows.Forms.Button();
            this.btn_2_2 = new System.Windows.Forms.Button();
            this.btn_2_1 = new System.Windows.Forms.Button();
            this.btn_2_0 = new System.Windows.Forms.Button();
            this.btn_1_6 = new System.Windows.Forms.Button();
            this.btn_1_5 = new System.Windows.Forms.Button();
            this.btn_1_4 = new System.Windows.Forms.Button();
            this.btn_1_3 = new System.Windows.Forms.Button();
            this.btn_1_2 = new System.Windows.Forms.Button();
            this.btn_1_1 = new System.Windows.Forms.Button();
            this.btn_1_0 = new System.Windows.Forms.Button();
            this.btn_0_6 = new System.Windows.Forms.Button();
            this.btn_0_5 = new System.Windows.Forms.Button();
            this.btn_0_4 = new System.Windows.Forms.Button();
            this.btn_0_3 = new System.Windows.Forms.Button();
            this.btn_0_2 = new System.Windows.Forms.Button();
            this.btn_0_1 = new System.Windows.Forms.Button();
            this.btn_0_0 = new System.Windows.Forms.Button();
            this.lbl_1Player = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_5_6
            // 
            this.btn_5_6.BackColor = System.Drawing.Color.Silver;
            this.btn_5_6.Location = new System.Drawing.Point(606, 470);
            this.btn_5_6.Name = "btn_5_6";
            this.btn_5_6.Size = new System.Drawing.Size(75, 75);
            this.btn_5_6.TabIndex = 126;
            this.btn_5_6.UseVisualStyleBackColor = false;
            this.btn_5_6.Click += new System.EventHandler(this.col6Click);
            this.btn_5_6.MouseEnter += new System.EventHandler(this.EnterCol06);
            this.btn_5_6.MouseLeave += new System.EventHandler(this.LeaveCol06);
            // 
            // btn_5_5
            // 
            this.btn_5_5.BackColor = System.Drawing.Color.Silver;
            this.btn_5_5.Location = new System.Drawing.Point(524, 470);
            this.btn_5_5.Name = "btn_5_5";
            this.btn_5_5.Size = new System.Drawing.Size(75, 75);
            this.btn_5_5.TabIndex = 125;
            this.btn_5_5.UseVisualStyleBackColor = false;
            this.btn_5_5.Click += new System.EventHandler(this.col5Click);
            this.btn_5_5.MouseEnter += new System.EventHandler(this.EnterCol05);
            this.btn_5_5.MouseLeave += new System.EventHandler(this.LeaveCol05);
            // 
            // btn_5_4
            // 
            this.btn_5_4.BackColor = System.Drawing.Color.Silver;
            this.btn_5_4.Location = new System.Drawing.Point(443, 470);
            this.btn_5_4.Name = "btn_5_4";
            this.btn_5_4.Size = new System.Drawing.Size(75, 75);
            this.btn_5_4.TabIndex = 124;
            this.btn_5_4.UseVisualStyleBackColor = false;
            this.btn_5_4.Click += new System.EventHandler(this.col4Click);
            this.btn_5_4.MouseEnter += new System.EventHandler(this.EnterCol04);
            this.btn_5_4.MouseLeave += new System.EventHandler(this.LeaveCol04);
            // 
            // btn_5_3
            // 
            this.btn_5_3.BackColor = System.Drawing.Color.Silver;
            this.btn_5_3.Location = new System.Drawing.Point(363, 470);
            this.btn_5_3.Name = "btn_5_3";
            this.btn_5_3.Size = new System.Drawing.Size(75, 75);
            this.btn_5_3.TabIndex = 123;
            this.btn_5_3.UseVisualStyleBackColor = false;
            this.btn_5_3.Click += new System.EventHandler(this.col3Click);
            this.btn_5_3.MouseEnter += new System.EventHandler(this.EnterCol03);
            this.btn_5_3.MouseLeave += new System.EventHandler(this.LeaveCol03);
            // 
            // btn_5_2
            // 
            this.btn_5_2.BackColor = System.Drawing.Color.Silver;
            this.btn_5_2.Location = new System.Drawing.Point(282, 470);
            this.btn_5_2.Name = "btn_5_2";
            this.btn_5_2.Size = new System.Drawing.Size(75, 75);
            this.btn_5_2.TabIndex = 122;
            this.btn_5_2.UseVisualStyleBackColor = false;
            this.btn_5_2.Click += new System.EventHandler(this.col2Click);
            this.btn_5_2.MouseEnter += new System.EventHandler(this.EnterCol02);
            this.btn_5_2.MouseLeave += new System.EventHandler(this.LeaveCol02);
            // 
            // btn_5_1
            // 
            this.btn_5_1.BackColor = System.Drawing.Color.Silver;
            this.btn_5_1.Location = new System.Drawing.Point(201, 470);
            this.btn_5_1.Name = "btn_5_1";
            this.btn_5_1.Size = new System.Drawing.Size(75, 75);
            this.btn_5_1.TabIndex = 121;
            this.btn_5_1.UseVisualStyleBackColor = false;
            this.btn_5_1.Click += new System.EventHandler(this.col1Click);
            this.btn_5_1.MouseEnter += new System.EventHandler(this.EnterCol01);
            this.btn_5_1.MouseLeave += new System.EventHandler(this.LeaveCol01);
            // 
            // btn_5_0
            // 
            this.btn_5_0.BackColor = System.Drawing.Color.Silver;
            this.btn_5_0.Location = new System.Drawing.Point(120, 470);
            this.btn_5_0.Name = "btn_5_0";
            this.btn_5_0.Size = new System.Drawing.Size(75, 75);
            this.btn_5_0.TabIndex = 120;
            this.btn_5_0.UseVisualStyleBackColor = false;
            this.btn_5_0.Click += new System.EventHandler(this.col0Click);
            this.btn_5_0.MouseEnter += new System.EventHandler(this.EnterCol00);
            this.btn_5_0.MouseLeave += new System.EventHandler(this.LeaveCol00);
            // 
            // btn_4_6
            // 
            this.btn_4_6.BackColor = System.Drawing.Color.Silver;
            this.btn_4_6.Location = new System.Drawing.Point(606, 389);
            this.btn_4_6.Name = "btn_4_6";
            this.btn_4_6.Size = new System.Drawing.Size(75, 75);
            this.btn_4_6.TabIndex = 119;
            this.btn_4_6.UseVisualStyleBackColor = false;
            this.btn_4_6.Click += new System.EventHandler(this.col6Click);
            this.btn_4_6.MouseEnter += new System.EventHandler(this.EnterCol06);
            this.btn_4_6.MouseLeave += new System.EventHandler(this.LeaveCol06);
            // 
            // btn_4_5
            // 
            this.btn_4_5.BackColor = System.Drawing.Color.Silver;
            this.btn_4_5.Location = new System.Drawing.Point(525, 389);
            this.btn_4_5.Name = "btn_4_5";
            this.btn_4_5.Size = new System.Drawing.Size(75, 75);
            this.btn_4_5.TabIndex = 118;
            this.btn_4_5.UseVisualStyleBackColor = false;
            this.btn_4_5.Click += new System.EventHandler(this.col5Click);
            this.btn_4_5.MouseEnter += new System.EventHandler(this.EnterCol05);
            this.btn_4_5.MouseLeave += new System.EventHandler(this.LeaveCol05);
            // 
            // btn_4_4
            // 
            this.btn_4_4.BackColor = System.Drawing.Color.Silver;
            this.btn_4_4.Location = new System.Drawing.Point(444, 389);
            this.btn_4_4.Name = "btn_4_4";
            this.btn_4_4.Size = new System.Drawing.Size(75, 75);
            this.btn_4_4.TabIndex = 117;
            this.btn_4_4.UseVisualStyleBackColor = false;
            this.btn_4_4.Click += new System.EventHandler(this.col4Click);
            this.btn_4_4.MouseEnter += new System.EventHandler(this.EnterCol04);
            this.btn_4_4.MouseLeave += new System.EventHandler(this.LeaveCol04);
            // 
            // btn_4_3
            // 
            this.btn_4_3.BackColor = System.Drawing.Color.Silver;
            this.btn_4_3.Location = new System.Drawing.Point(363, 389);
            this.btn_4_3.Name = "btn_4_3";
            this.btn_4_3.Size = new System.Drawing.Size(75, 75);
            this.btn_4_3.TabIndex = 116;
            this.btn_4_3.UseVisualStyleBackColor = false;
            this.btn_4_3.Click += new System.EventHandler(this.col3Click);
            this.btn_4_3.MouseEnter += new System.EventHandler(this.EnterCol03);
            this.btn_4_3.MouseLeave += new System.EventHandler(this.LeaveCol03);
            // 
            // btn_4_2
            // 
            this.btn_4_2.BackColor = System.Drawing.Color.Silver;
            this.btn_4_2.Location = new System.Drawing.Point(282, 389);
            this.btn_4_2.Name = "btn_4_2";
            this.btn_4_2.Size = new System.Drawing.Size(75, 75);
            this.btn_4_2.TabIndex = 115;
            this.btn_4_2.UseVisualStyleBackColor = false;
            this.btn_4_2.Click += new System.EventHandler(this.col2Click);
            this.btn_4_2.MouseEnter += new System.EventHandler(this.EnterCol02);
            this.btn_4_2.MouseLeave += new System.EventHandler(this.LeaveCol02);
            // 
            // btn_4_1
            // 
            this.btn_4_1.BackColor = System.Drawing.Color.Silver;
            this.btn_4_1.Location = new System.Drawing.Point(201, 389);
            this.btn_4_1.Name = "btn_4_1";
            this.btn_4_1.Size = new System.Drawing.Size(75, 75);
            this.btn_4_1.TabIndex = 114;
            this.btn_4_1.UseVisualStyleBackColor = false;
            this.btn_4_1.Click += new System.EventHandler(this.col1Click);
            this.btn_4_1.MouseEnter += new System.EventHandler(this.EnterCol01);
            this.btn_4_1.MouseLeave += new System.EventHandler(this.LeaveCol01);
            // 
            // btn_4_0
            // 
            this.btn_4_0.BackColor = System.Drawing.Color.Silver;
            this.btn_4_0.Location = new System.Drawing.Point(120, 389);
            this.btn_4_0.Name = "btn_4_0";
            this.btn_4_0.Size = new System.Drawing.Size(75, 75);
            this.btn_4_0.TabIndex = 113;
            this.btn_4_0.UseVisualStyleBackColor = false;
            this.btn_4_0.Click += new System.EventHandler(this.col0Click);
            this.btn_4_0.MouseEnter += new System.EventHandler(this.EnterCol00);
            this.btn_4_0.MouseLeave += new System.EventHandler(this.LeaveCol00);
            // 
            // btn_3_6
            // 
            this.btn_3_6.BackColor = System.Drawing.Color.Silver;
            this.btn_3_6.Location = new System.Drawing.Point(606, 308);
            this.btn_3_6.Name = "btn_3_6";
            this.btn_3_6.Size = new System.Drawing.Size(75, 75);
            this.btn_3_6.TabIndex = 112;
            this.btn_3_6.UseVisualStyleBackColor = false;
            this.btn_3_6.Click += new System.EventHandler(this.col6Click);
            this.btn_3_6.MouseEnter += new System.EventHandler(this.EnterCol06);
            this.btn_3_6.MouseLeave += new System.EventHandler(this.LeaveCol06);
            // 
            // btn_3_5
            // 
            this.btn_3_5.BackColor = System.Drawing.Color.Silver;
            this.btn_3_5.Location = new System.Drawing.Point(525, 308);
            this.btn_3_5.Name = "btn_3_5";
            this.btn_3_5.Size = new System.Drawing.Size(75, 75);
            this.btn_3_5.TabIndex = 111;
            this.btn_3_5.UseVisualStyleBackColor = false;
            this.btn_3_5.Click += new System.EventHandler(this.col5Click);
            this.btn_3_5.MouseEnter += new System.EventHandler(this.EnterCol05);
            this.btn_3_5.MouseLeave += new System.EventHandler(this.LeaveCol05);
            // 
            // btn_3_4
            // 
            this.btn_3_4.BackColor = System.Drawing.Color.Silver;
            this.btn_3_4.Location = new System.Drawing.Point(444, 308);
            this.btn_3_4.Name = "btn_3_4";
            this.btn_3_4.Size = new System.Drawing.Size(75, 75);
            this.btn_3_4.TabIndex = 110;
            this.btn_3_4.UseVisualStyleBackColor = false;
            this.btn_3_4.Click += new System.EventHandler(this.col4Click);
            this.btn_3_4.MouseEnter += new System.EventHandler(this.EnterCol04);
            this.btn_3_4.MouseLeave += new System.EventHandler(this.LeaveCol04);
            // 
            // btn_3_3
            // 
            this.btn_3_3.BackColor = System.Drawing.Color.Silver;
            this.btn_3_3.Location = new System.Drawing.Point(363, 308);
            this.btn_3_3.Name = "btn_3_3";
            this.btn_3_3.Size = new System.Drawing.Size(75, 75);
            this.btn_3_3.TabIndex = 109;
            this.btn_3_3.UseVisualStyleBackColor = false;
            this.btn_3_3.Click += new System.EventHandler(this.col3Click);
            this.btn_3_3.MouseEnter += new System.EventHandler(this.EnterCol03);
            this.btn_3_3.MouseLeave += new System.EventHandler(this.LeaveCol03);
            // 
            // btn_3_2
            // 
            this.btn_3_2.BackColor = System.Drawing.Color.Silver;
            this.btn_3_2.Location = new System.Drawing.Point(282, 308);
            this.btn_3_2.Name = "btn_3_2";
            this.btn_3_2.Size = new System.Drawing.Size(75, 75);
            this.btn_3_2.TabIndex = 108;
            this.btn_3_2.UseVisualStyleBackColor = false;
            this.btn_3_2.Click += new System.EventHandler(this.col2Click);
            this.btn_3_2.MouseEnter += new System.EventHandler(this.EnterCol02);
            this.btn_3_2.MouseLeave += new System.EventHandler(this.LeaveCol02);
            // 
            // btn_3_1
            // 
            this.btn_3_1.BackColor = System.Drawing.Color.Silver;
            this.btn_3_1.Location = new System.Drawing.Point(201, 308);
            this.btn_3_1.Name = "btn_3_1";
            this.btn_3_1.Size = new System.Drawing.Size(75, 75);
            this.btn_3_1.TabIndex = 107;
            this.btn_3_1.UseVisualStyleBackColor = false;
            this.btn_3_1.Click += new System.EventHandler(this.col1Click);
            this.btn_3_1.MouseEnter += new System.EventHandler(this.EnterCol01);
            this.btn_3_1.MouseLeave += new System.EventHandler(this.LeaveCol01);
            // 
            // btn_3_0
            // 
            this.btn_3_0.BackColor = System.Drawing.Color.Silver;
            this.btn_3_0.Location = new System.Drawing.Point(120, 308);
            this.btn_3_0.Name = "btn_3_0";
            this.btn_3_0.Size = new System.Drawing.Size(75, 75);
            this.btn_3_0.TabIndex = 106;
            this.btn_3_0.UseVisualStyleBackColor = false;
            this.btn_3_0.Click += new System.EventHandler(this.col0Click);
            this.btn_3_0.MouseEnter += new System.EventHandler(this.EnterCol00);
            this.btn_3_0.MouseLeave += new System.EventHandler(this.LeaveCol00);
            // 
            // btn_2_6
            // 
            this.btn_2_6.BackColor = System.Drawing.Color.Silver;
            this.btn_2_6.Location = new System.Drawing.Point(606, 227);
            this.btn_2_6.Name = "btn_2_6";
            this.btn_2_6.Size = new System.Drawing.Size(75, 75);
            this.btn_2_6.TabIndex = 105;
            this.btn_2_6.UseVisualStyleBackColor = false;
            this.btn_2_6.Click += new System.EventHandler(this.col6Click);
            this.btn_2_6.MouseEnter += new System.EventHandler(this.EnterCol06);
            this.btn_2_6.MouseLeave += new System.EventHandler(this.LeaveCol06);
            // 
            // btn_2_5
            // 
            this.btn_2_5.BackColor = System.Drawing.Color.Silver;
            this.btn_2_5.Location = new System.Drawing.Point(525, 227);
            this.btn_2_5.Name = "btn_2_5";
            this.btn_2_5.Size = new System.Drawing.Size(75, 75);
            this.btn_2_5.TabIndex = 104;
            this.btn_2_5.UseVisualStyleBackColor = false;
            this.btn_2_5.Click += new System.EventHandler(this.col5Click);
            this.btn_2_5.MouseEnter += new System.EventHandler(this.EnterCol05);
            this.btn_2_5.MouseLeave += new System.EventHandler(this.LeaveCol05);
            // 
            // btn_2_4
            // 
            this.btn_2_4.BackColor = System.Drawing.Color.Silver;
            this.btn_2_4.Location = new System.Drawing.Point(444, 227);
            this.btn_2_4.Name = "btn_2_4";
            this.btn_2_4.Size = new System.Drawing.Size(75, 75);
            this.btn_2_4.TabIndex = 103;
            this.btn_2_4.UseVisualStyleBackColor = false;
            this.btn_2_4.Click += new System.EventHandler(this.col4Click);
            this.btn_2_4.MouseEnter += new System.EventHandler(this.EnterCol04);
            this.btn_2_4.MouseLeave += new System.EventHandler(this.LeaveCol04);
            // 
            // btn_2_3
            // 
            this.btn_2_3.BackColor = System.Drawing.Color.Silver;
            this.btn_2_3.Location = new System.Drawing.Point(363, 227);
            this.btn_2_3.Name = "btn_2_3";
            this.btn_2_3.Size = new System.Drawing.Size(75, 75);
            this.btn_2_3.TabIndex = 102;
            this.btn_2_3.UseVisualStyleBackColor = false;
            this.btn_2_3.Click += new System.EventHandler(this.col3Click);
            this.btn_2_3.MouseEnter += new System.EventHandler(this.EnterCol03);
            this.btn_2_3.MouseLeave += new System.EventHandler(this.LeaveCol03);
            // 
            // btn_2_2
            // 
            this.btn_2_2.BackColor = System.Drawing.Color.Silver;
            this.btn_2_2.Location = new System.Drawing.Point(282, 227);
            this.btn_2_2.Name = "btn_2_2";
            this.btn_2_2.Size = new System.Drawing.Size(75, 75);
            this.btn_2_2.TabIndex = 101;
            this.btn_2_2.UseVisualStyleBackColor = false;
            this.btn_2_2.Click += new System.EventHandler(this.col2Click);
            this.btn_2_2.MouseEnter += new System.EventHandler(this.EnterCol02);
            this.btn_2_2.MouseLeave += new System.EventHandler(this.LeaveCol02);
            // 
            // btn_2_1
            // 
            this.btn_2_1.BackColor = System.Drawing.Color.Silver;
            this.btn_2_1.Location = new System.Drawing.Point(201, 227);
            this.btn_2_1.Name = "btn_2_1";
            this.btn_2_1.Size = new System.Drawing.Size(75, 75);
            this.btn_2_1.TabIndex = 100;
            this.btn_2_1.UseVisualStyleBackColor = false;
            this.btn_2_1.Click += new System.EventHandler(this.col1Click);
            this.btn_2_1.MouseEnter += new System.EventHandler(this.EnterCol01);
            this.btn_2_1.MouseLeave += new System.EventHandler(this.LeaveCol01);
            // 
            // btn_2_0
            // 
            this.btn_2_0.BackColor = System.Drawing.Color.Silver;
            this.btn_2_0.Location = new System.Drawing.Point(120, 227);
            this.btn_2_0.Name = "btn_2_0";
            this.btn_2_0.Size = new System.Drawing.Size(75, 75);
            this.btn_2_0.TabIndex = 99;
            this.btn_2_0.UseVisualStyleBackColor = false;
            this.btn_2_0.Click += new System.EventHandler(this.col0Click);
            this.btn_2_0.MouseEnter += new System.EventHandler(this.EnterCol00);
            this.btn_2_0.MouseLeave += new System.EventHandler(this.LeaveCol00);
            // 
            // btn_1_6
            // 
            this.btn_1_6.BackColor = System.Drawing.Color.Silver;
            this.btn_1_6.Location = new System.Drawing.Point(606, 146);
            this.btn_1_6.Name = "btn_1_6";
            this.btn_1_6.Size = new System.Drawing.Size(75, 75);
            this.btn_1_6.TabIndex = 98;
            this.btn_1_6.UseVisualStyleBackColor = false;
            this.btn_1_6.Click += new System.EventHandler(this.col6Click);
            this.btn_1_6.MouseEnter += new System.EventHandler(this.EnterCol06);
            this.btn_1_6.MouseLeave += new System.EventHandler(this.LeaveCol06);
            // 
            // btn_1_5
            // 
            this.btn_1_5.BackColor = System.Drawing.Color.Silver;
            this.btn_1_5.Location = new System.Drawing.Point(525, 146);
            this.btn_1_5.Name = "btn_1_5";
            this.btn_1_5.Size = new System.Drawing.Size(75, 75);
            this.btn_1_5.TabIndex = 97;
            this.btn_1_5.UseVisualStyleBackColor = false;
            this.btn_1_5.Click += new System.EventHandler(this.col5Click);
            this.btn_1_5.MouseEnter += new System.EventHandler(this.EnterCol05);
            this.btn_1_5.MouseLeave += new System.EventHandler(this.LeaveCol05);
            // 
            // btn_1_4
            // 
            this.btn_1_4.BackColor = System.Drawing.Color.Silver;
            this.btn_1_4.Location = new System.Drawing.Point(444, 146);
            this.btn_1_4.Name = "btn_1_4";
            this.btn_1_4.Size = new System.Drawing.Size(75, 75);
            this.btn_1_4.TabIndex = 96;
            this.btn_1_4.UseVisualStyleBackColor = false;
            this.btn_1_4.Click += new System.EventHandler(this.col4Click);
            this.btn_1_4.MouseEnter += new System.EventHandler(this.EnterCol04);
            this.btn_1_4.MouseLeave += new System.EventHandler(this.LeaveCol04);
            // 
            // btn_1_3
            // 
            this.btn_1_3.BackColor = System.Drawing.Color.Silver;
            this.btn_1_3.Location = new System.Drawing.Point(363, 146);
            this.btn_1_3.Name = "btn_1_3";
            this.btn_1_3.Size = new System.Drawing.Size(75, 75);
            this.btn_1_3.TabIndex = 95;
            this.btn_1_3.UseVisualStyleBackColor = false;
            this.btn_1_3.Click += new System.EventHandler(this.col3Click);
            this.btn_1_3.MouseEnter += new System.EventHandler(this.EnterCol03);
            this.btn_1_3.MouseLeave += new System.EventHandler(this.LeaveCol03);
            // 
            // btn_1_2
            // 
            this.btn_1_2.BackColor = System.Drawing.Color.Silver;
            this.btn_1_2.Location = new System.Drawing.Point(282, 146);
            this.btn_1_2.Name = "btn_1_2";
            this.btn_1_2.Size = new System.Drawing.Size(75, 75);
            this.btn_1_2.TabIndex = 94;
            this.btn_1_2.UseVisualStyleBackColor = false;
            this.btn_1_2.Click += new System.EventHandler(this.col2Click);
            this.btn_1_2.MouseEnter += new System.EventHandler(this.EnterCol02);
            this.btn_1_2.MouseLeave += new System.EventHandler(this.LeaveCol02);
            // 
            // btn_1_1
            // 
            this.btn_1_1.BackColor = System.Drawing.Color.Silver;
            this.btn_1_1.Location = new System.Drawing.Point(201, 146);
            this.btn_1_1.Name = "btn_1_1";
            this.btn_1_1.Size = new System.Drawing.Size(75, 75);
            this.btn_1_1.TabIndex = 93;
            this.btn_1_1.UseVisualStyleBackColor = false;
            this.btn_1_1.Click += new System.EventHandler(this.col1Click);
            this.btn_1_1.MouseEnter += new System.EventHandler(this.EnterCol01);
            this.btn_1_1.MouseLeave += new System.EventHandler(this.LeaveCol01);
            // 
            // btn_1_0
            // 
            this.btn_1_0.BackColor = System.Drawing.Color.Silver;
            this.btn_1_0.Location = new System.Drawing.Point(120, 146);
            this.btn_1_0.Name = "btn_1_0";
            this.btn_1_0.Size = new System.Drawing.Size(75, 75);
            this.btn_1_0.TabIndex = 92;
            this.btn_1_0.UseVisualStyleBackColor = false;
            this.btn_1_0.Click += new System.EventHandler(this.col0Click);
            this.btn_1_0.MouseEnter += new System.EventHandler(this.EnterCol00);
            this.btn_1_0.MouseLeave += new System.EventHandler(this.LeaveCol00);
            // 
            // btn_0_6
            // 
            this.btn_0_6.BackColor = System.Drawing.Color.Silver;
            this.btn_0_6.Location = new System.Drawing.Point(606, 65);
            this.btn_0_6.Name = "btn_0_6";
            this.btn_0_6.Size = new System.Drawing.Size(75, 75);
            this.btn_0_6.TabIndex = 91;
            this.btn_0_6.UseVisualStyleBackColor = false;
            this.btn_0_6.Click += new System.EventHandler(this.col6Click);
            this.btn_0_6.MouseEnter += new System.EventHandler(this.EnterCol06);
            this.btn_0_6.MouseLeave += new System.EventHandler(this.LeaveCol06);
            // 
            // btn_0_5
            // 
            this.btn_0_5.BackColor = System.Drawing.Color.Silver;
            this.btn_0_5.Location = new System.Drawing.Point(525, 65);
            this.btn_0_5.Name = "btn_0_5";
            this.btn_0_5.Size = new System.Drawing.Size(75, 75);
            this.btn_0_5.TabIndex = 90;
            this.btn_0_5.UseVisualStyleBackColor = false;
            this.btn_0_5.Click += new System.EventHandler(this.col5Click);
            this.btn_0_5.MouseEnter += new System.EventHandler(this.EnterCol05);
            this.btn_0_5.MouseLeave += new System.EventHandler(this.LeaveCol05);
            // 
            // btn_0_4
            // 
            this.btn_0_4.BackColor = System.Drawing.Color.Silver;
            this.btn_0_4.Location = new System.Drawing.Point(444, 65);
            this.btn_0_4.Name = "btn_0_4";
            this.btn_0_4.Size = new System.Drawing.Size(75, 75);
            this.btn_0_4.TabIndex = 89;
            this.btn_0_4.UseVisualStyleBackColor = false;
            this.btn_0_4.Click += new System.EventHandler(this.col4Click);
            this.btn_0_4.MouseEnter += new System.EventHandler(this.EnterCol04);
            this.btn_0_4.MouseLeave += new System.EventHandler(this.LeaveCol04);
            // 
            // btn_0_3
            // 
            this.btn_0_3.BackColor = System.Drawing.Color.Silver;
            this.btn_0_3.Location = new System.Drawing.Point(363, 65);
            this.btn_0_3.Name = "btn_0_3";
            this.btn_0_3.Size = new System.Drawing.Size(75, 75);
            this.btn_0_3.TabIndex = 88;
            this.btn_0_3.UseVisualStyleBackColor = false;
            this.btn_0_3.Click += new System.EventHandler(this.col3Click);
            this.btn_0_3.MouseEnter += new System.EventHandler(this.EnterCol03);
            this.btn_0_3.MouseLeave += new System.EventHandler(this.LeaveCol03);
            // 
            // btn_0_2
            // 
            this.btn_0_2.BackColor = System.Drawing.Color.Silver;
            this.btn_0_2.Location = new System.Drawing.Point(282, 65);
            this.btn_0_2.Name = "btn_0_2";
            this.btn_0_2.Size = new System.Drawing.Size(75, 75);
            this.btn_0_2.TabIndex = 87;
            this.btn_0_2.UseVisualStyleBackColor = false;
            this.btn_0_2.Click += new System.EventHandler(this.col2Click);
            this.btn_0_2.MouseEnter += new System.EventHandler(this.EnterCol02);
            this.btn_0_2.MouseLeave += new System.EventHandler(this.LeaveCol02);
            // 
            // btn_0_1
            // 
            this.btn_0_1.BackColor = System.Drawing.Color.Silver;
            this.btn_0_1.Location = new System.Drawing.Point(201, 65);
            this.btn_0_1.Name = "btn_0_1";
            this.btn_0_1.Size = new System.Drawing.Size(75, 75);
            this.btn_0_1.TabIndex = 86;
            this.btn_0_1.UseVisualStyleBackColor = false;
            this.btn_0_1.Click += new System.EventHandler(this.col1Click);
            this.btn_0_1.MouseEnter += new System.EventHandler(this.EnterCol01);
            this.btn_0_1.MouseLeave += new System.EventHandler(this.LeaveCol01);
            // 
            // btn_0_0
            // 
            this.btn_0_0.BackColor = System.Drawing.Color.Silver;
            this.btn_0_0.Location = new System.Drawing.Point(120, 65);
            this.btn_0_0.Name = "btn_0_0";
            this.btn_0_0.Size = new System.Drawing.Size(75, 75);
            this.btn_0_0.TabIndex = 85;
            this.btn_0_0.UseVisualStyleBackColor = false;
            this.btn_0_0.Click += new System.EventHandler(this.col0Click);
            this.btn_0_0.MouseEnter += new System.EventHandler(this.EnterCol00);
            this.btn_0_0.MouseLeave += new System.EventHandler(this.LeaveCol00);
            // 
            // lbl_1Player
            // 
            this.lbl_1Player.AutoSize = true;
            this.lbl_1Player.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_1Player.Location = new System.Drawing.Point(327, 18);
            this.lbl_1Player.Name = "lbl_1Player";
            this.lbl_1Player.Size = new System.Drawing.Size(151, 25);
            this.lbl_1Player.TabIndex = 127;
            this.lbl_1Player.Text = "1 Player Mode";
            // 
            // _1Player
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 611);
            this.Controls.Add(this.lbl_1Player);
            this.Controls.Add(this.btn_5_6);
            this.Controls.Add(this.btn_5_5);
            this.Controls.Add(this.btn_5_4);
            this.Controls.Add(this.btn_5_3);
            this.Controls.Add(this.btn_5_2);
            this.Controls.Add(this.btn_5_1);
            this.Controls.Add(this.btn_5_0);
            this.Controls.Add(this.btn_4_6);
            this.Controls.Add(this.btn_4_5);
            this.Controls.Add(this.btn_4_4);
            this.Controls.Add(this.btn_4_3);
            this.Controls.Add(this.btn_4_2);
            this.Controls.Add(this.btn_4_1);
            this.Controls.Add(this.btn_4_0);
            this.Controls.Add(this.btn_3_6);
            this.Controls.Add(this.btn_3_5);
            this.Controls.Add(this.btn_3_4);
            this.Controls.Add(this.btn_3_3);
            this.Controls.Add(this.btn_3_2);
            this.Controls.Add(this.btn_3_1);
            this.Controls.Add(this.btn_3_0);
            this.Controls.Add(this.btn_2_6);
            this.Controls.Add(this.btn_2_5);
            this.Controls.Add(this.btn_2_4);
            this.Controls.Add(this.btn_2_3);
            this.Controls.Add(this.btn_2_2);
            this.Controls.Add(this.btn_2_1);
            this.Controls.Add(this.btn_2_0);
            this.Controls.Add(this.btn_1_6);
            this.Controls.Add(this.btn_1_5);
            this.Controls.Add(this.btn_1_4);
            this.Controls.Add(this.btn_1_3);
            this.Controls.Add(this.btn_1_2);
            this.Controls.Add(this.btn_1_1);
            this.Controls.Add(this.btn_1_0);
            this.Controls.Add(this.btn_0_6);
            this.Controls.Add(this.btn_0_5);
            this.Controls.Add(this.btn_0_4);
            this.Controls.Add(this.btn_0_3);
            this.Controls.Add(this.btn_0_2);
            this.Controls.Add(this.btn_0_1);
            this.Controls.Add(this.btn_0_0);
            this.Name = "_1Player";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "_1Player";
            this.Load += new System.EventHandler(this._1Player_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_5_6;
        private System.Windows.Forms.Button btn_5_5;
        private System.Windows.Forms.Button btn_5_4;
        private System.Windows.Forms.Button btn_5_3;
        private System.Windows.Forms.Button btn_5_2;
        private System.Windows.Forms.Button btn_5_1;
        private System.Windows.Forms.Button btn_5_0;
        private System.Windows.Forms.Button btn_4_6;
        private System.Windows.Forms.Button btn_4_5;
        private System.Windows.Forms.Button btn_4_4;
        private System.Windows.Forms.Button btn_4_3;
        private System.Windows.Forms.Button btn_4_2;
        private System.Windows.Forms.Button btn_4_1;
        private System.Windows.Forms.Button btn_4_0;
        private System.Windows.Forms.Button btn_3_6;
        private System.Windows.Forms.Button btn_3_5;
        private System.Windows.Forms.Button btn_3_4;
        private System.Windows.Forms.Button btn_3_3;
        private System.Windows.Forms.Button btn_3_2;
        private System.Windows.Forms.Button btn_3_1;
        private System.Windows.Forms.Button btn_3_0;
        private System.Windows.Forms.Button btn_2_6;
        private System.Windows.Forms.Button btn_2_5;
        private System.Windows.Forms.Button btn_2_4;
        private System.Windows.Forms.Button btn_2_3;
        private System.Windows.Forms.Button btn_2_2;
        private System.Windows.Forms.Button btn_2_1;
        private System.Windows.Forms.Button btn_2_0;
        private System.Windows.Forms.Button btn_1_6;
        private System.Windows.Forms.Button btn_1_5;
        private System.Windows.Forms.Button btn_1_4;
        private System.Windows.Forms.Button btn_1_3;
        private System.Windows.Forms.Button btn_1_2;
        private System.Windows.Forms.Button btn_1_1;
        private System.Windows.Forms.Button btn_1_0;
        private System.Windows.Forms.Button btn_0_6;
        private System.Windows.Forms.Button btn_0_5;
        private System.Windows.Forms.Button btn_0_4;
        private System.Windows.Forms.Button btn_0_3;
        private System.Windows.Forms.Button btn_0_2;
        private System.Windows.Forms.Button btn_0_1;
        private System.Windows.Forms.Button btn_0_0;
        private System.Windows.Forms.Label lbl_1Player;
    }
}