﻿
namespace CIS153_GitHubExample
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_5_6 = new System.Windows.Forms.Button();
            this.btn_5_5 = new System.Windows.Forms.Button();
            this.btn_5_4 = new System.Windows.Forms.Button();
            this.btn_5_3 = new System.Windows.Forms.Button();
            this.btn_5_2 = new System.Windows.Forms.Button();
            this.btn_5_1 = new System.Windows.Forms.Button();
            this.btn_5_0 = new System.Windows.Forms.Button();
            this.btn_4_6 = new System.Windows.Forms.Button();
            this.btn_4_5 = new System.Windows.Forms.Button();
            this.btn_4_4 = new System.Windows.Forms.Button();
            this.btn_4_3 = new System.Windows.Forms.Button();
            this.btn_4_2 = new System.Windows.Forms.Button();
            this.btn_4_1 = new System.Windows.Forms.Button();
            this.btn_4_0 = new System.Windows.Forms.Button();
            this.btn_3_6 = new System.Windows.Forms.Button();
            this.btn_3_5 = new System.Windows.Forms.Button();
            this.btn_3_4 = new System.Windows.Forms.Button();
            this.btn_3_3 = new System.Windows.Forms.Button();
            this.btn_3_2 = new System.Windows.Forms.Button();
            this.btn_3_1 = new System.Windows.Forms.Button();
            this.btn_3_0 = new System.Windows.Forms.Button();
            this.btn_2_6 = new System.Windows.Forms.Button();
            this.btn_2_5 = new System.Windows.Forms.Button();
            this.btn_2_4 = new System.Windows.Forms.Button();
            this.btn_2_3 = new System.Windows.Forms.Button();
            this.btn_2_2 = new System.Windows.Forms.Button();
            this.btn_2_1 = new System.Windows.Forms.Button();
            this.btn_2_0 = new System.Windows.Forms.Button();
            this.btn_1_6 = new System.Windows.Forms.Button();
            this.btn_1_5 = new System.Windows.Forms.Button();
            this.btn_1_4 = new System.Windows.Forms.Button();
            this.btn_1_3 = new System.Windows.Forms.Button();
            this.btn_1_2 = new System.Windows.Forms.Button();
            this.btn_1_1 = new System.Windows.Forms.Button();
            this.btn_1_0 = new System.Windows.Forms.Button();
            this.btn_0_6 = new System.Windows.Forms.Button();
            this.btn_0_5 = new System.Windows.Forms.Button();
            this.btn_0_4 = new System.Windows.Forms.Button();
            this.btn_0_3 = new System.Windows.Forms.Button();
            this.btn_0_2 = new System.Windows.Forms.Button();
            this.btn_0_1 = new System.Windows.Forms.Button();
            this.btn_0_0 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_5_6
            // 
            this.btn_5_6.Location = new System.Drawing.Point(641, 489);
            this.btn_5_6.Name = "btn_5_6";
            this.btn_5_6.Size = new System.Drawing.Size(75, 75);
            this.btn_5_6.TabIndex = 84;
            this.btn_5_6.UseVisualStyleBackColor = true;
            this.btn_5_6.Click += new System.EventHandler(this.col6Click);
            // 
            // btn_5_5
            // 
            this.btn_5_5.Location = new System.Drawing.Point(559, 489);
            this.btn_5_5.Name = "btn_5_5";
            this.btn_5_5.Size = new System.Drawing.Size(75, 75);
            this.btn_5_5.TabIndex = 83;
            this.btn_5_5.UseVisualStyleBackColor = true;
            this.btn_5_5.Click += new System.EventHandler(this.col5Click);
            // 
            // btn_5_4
            // 
            this.btn_5_4.Location = new System.Drawing.Point(478, 489);
            this.btn_5_4.Name = "btn_5_4";
            this.btn_5_4.Size = new System.Drawing.Size(75, 75);
            this.btn_5_4.TabIndex = 82;
            this.btn_5_4.UseVisualStyleBackColor = true;
            this.btn_5_4.Click += new System.EventHandler(this.col4Click);
            // 
            // btn_5_3
            // 
            this.btn_5_3.Location = new System.Drawing.Point(398, 489);
            this.btn_5_3.Name = "btn_5_3";
            this.btn_5_3.Size = new System.Drawing.Size(75, 75);
            this.btn_5_3.TabIndex = 81;
            this.btn_5_3.UseVisualStyleBackColor = true;
            this.btn_5_3.Click += new System.EventHandler(this.col3Click);
            // 
            // btn_5_2
            // 
            this.btn_5_2.Location = new System.Drawing.Point(317, 489);
            this.btn_5_2.Name = "btn_5_2";
            this.btn_5_2.Size = new System.Drawing.Size(75, 75);
            this.btn_5_2.TabIndex = 80;
            this.btn_5_2.UseVisualStyleBackColor = true;
            this.btn_5_2.Click += new System.EventHandler(this.col2Click);
            // 
            // btn_5_1
            // 
            this.btn_5_1.Location = new System.Drawing.Point(236, 489);
            this.btn_5_1.Name = "btn_5_1";
            this.btn_5_1.Size = new System.Drawing.Size(75, 75);
            this.btn_5_1.TabIndex = 79;
            this.btn_5_1.UseVisualStyleBackColor = true;
            this.btn_5_1.Click += new System.EventHandler(this.col1Click);
            // 
            // btn_5_0
            // 
            this.btn_5_0.Location = new System.Drawing.Point(155, 489);
            this.btn_5_0.Name = "btn_5_0";
            this.btn_5_0.Size = new System.Drawing.Size(75, 75);
            this.btn_5_0.TabIndex = 78;
            this.btn_5_0.UseVisualStyleBackColor = true;
            this.btn_5_0.Click += new System.EventHandler(this.col0Click);
            // 
            // btn_4_6
            // 
            this.btn_4_6.Location = new System.Drawing.Point(641, 408);
            this.btn_4_6.Name = "btn_4_6";
            this.btn_4_6.Size = new System.Drawing.Size(75, 75);
            this.btn_4_6.TabIndex = 77;
            this.btn_4_6.UseVisualStyleBackColor = true;
            this.btn_4_6.Click += new System.EventHandler(this.col6Click);
            // 
            // btn_4_5
            // 
            this.btn_4_5.Location = new System.Drawing.Point(560, 408);
            this.btn_4_5.Name = "btn_4_5";
            this.btn_4_5.Size = new System.Drawing.Size(75, 75);
            this.btn_4_5.TabIndex = 76;
            this.btn_4_5.UseVisualStyleBackColor = true;
            this.btn_4_5.Click += new System.EventHandler(this.col5Click);
            // 
            // btn_4_4
            // 
            this.btn_4_4.Location = new System.Drawing.Point(479, 408);
            this.btn_4_4.Name = "btn_4_4";
            this.btn_4_4.Size = new System.Drawing.Size(75, 75);
            this.btn_4_4.TabIndex = 75;
            this.btn_4_4.UseVisualStyleBackColor = true;
            this.btn_4_4.Click += new System.EventHandler(this.col4Click);
            // 
            // btn_4_3
            // 
            this.btn_4_3.Location = new System.Drawing.Point(398, 408);
            this.btn_4_3.Name = "btn_4_3";
            this.btn_4_3.Size = new System.Drawing.Size(75, 75);
            this.btn_4_3.TabIndex = 74;
            this.btn_4_3.UseVisualStyleBackColor = true;
            this.btn_4_3.Click += new System.EventHandler(this.col3Click);
            // 
            // btn_4_2
            // 
            this.btn_4_2.Location = new System.Drawing.Point(317, 408);
            this.btn_4_2.Name = "btn_4_2";
            this.btn_4_2.Size = new System.Drawing.Size(75, 75);
            this.btn_4_2.TabIndex = 73;
            this.btn_4_2.UseVisualStyleBackColor = true;
            this.btn_4_2.Click += new System.EventHandler(this.col2Click);
            // 
            // btn_4_1
            // 
            this.btn_4_1.Location = new System.Drawing.Point(236, 408);
            this.btn_4_1.Name = "btn_4_1";
            this.btn_4_1.Size = new System.Drawing.Size(75, 75);
            this.btn_4_1.TabIndex = 72;
            this.btn_4_1.UseVisualStyleBackColor = true;
            this.btn_4_1.Click += new System.EventHandler(this.col1Click);
            // 
            // btn_4_0
            // 
            this.btn_4_0.Location = new System.Drawing.Point(155, 408);
            this.btn_4_0.Name = "btn_4_0";
            this.btn_4_0.Size = new System.Drawing.Size(75, 75);
            this.btn_4_0.TabIndex = 71;
            this.btn_4_0.UseVisualStyleBackColor = true;
            this.btn_4_0.Click += new System.EventHandler(this.col0Click);
            // 
            // btn_3_6
            // 
            this.btn_3_6.Location = new System.Drawing.Point(641, 327);
            this.btn_3_6.Name = "btn_3_6";
            this.btn_3_6.Size = new System.Drawing.Size(75, 75);
            this.btn_3_6.TabIndex = 70;
            this.btn_3_6.UseVisualStyleBackColor = true;
            this.btn_3_6.Click += new System.EventHandler(this.col6Click);
            // 
            // btn_3_5
            // 
            this.btn_3_5.Location = new System.Drawing.Point(560, 327);
            this.btn_3_5.Name = "btn_3_5";
            this.btn_3_5.Size = new System.Drawing.Size(75, 75);
            this.btn_3_5.TabIndex = 69;
            this.btn_3_5.UseVisualStyleBackColor = true;
            this.btn_3_5.Click += new System.EventHandler(this.col5Click);
            // 
            // btn_3_4
            // 
            this.btn_3_4.Location = new System.Drawing.Point(479, 327);
            this.btn_3_4.Name = "btn_3_4";
            this.btn_3_4.Size = new System.Drawing.Size(75, 75);
            this.btn_3_4.TabIndex = 68;
            this.btn_3_4.UseVisualStyleBackColor = true;
            this.btn_3_4.Click += new System.EventHandler(this.col4Click);
            // 
            // btn_3_3
            // 
            this.btn_3_3.Location = new System.Drawing.Point(398, 327);
            this.btn_3_3.Name = "btn_3_3";
            this.btn_3_3.Size = new System.Drawing.Size(75, 75);
            this.btn_3_3.TabIndex = 67;
            this.btn_3_3.UseVisualStyleBackColor = true;
            this.btn_3_3.Click += new System.EventHandler(this.col3Click);
            // 
            // btn_3_2
            // 
            this.btn_3_2.Location = new System.Drawing.Point(317, 327);
            this.btn_3_2.Name = "btn_3_2";
            this.btn_3_2.Size = new System.Drawing.Size(75, 75);
            this.btn_3_2.TabIndex = 66;
            this.btn_3_2.UseVisualStyleBackColor = true;
            this.btn_3_2.Click += new System.EventHandler(this.col2Click);
            // 
            // btn_3_1
            // 
            this.btn_3_1.Location = new System.Drawing.Point(236, 327);
            this.btn_3_1.Name = "btn_3_1";
            this.btn_3_1.Size = new System.Drawing.Size(75, 75);
            this.btn_3_1.TabIndex = 65;
            this.btn_3_1.UseVisualStyleBackColor = true;
            this.btn_3_1.Click += new System.EventHandler(this.col1Click);
            // 
            // btn_3_0
            // 
            this.btn_3_0.Location = new System.Drawing.Point(155, 327);
            this.btn_3_0.Name = "btn_3_0";
            this.btn_3_0.Size = new System.Drawing.Size(75, 75);
            this.btn_3_0.TabIndex = 64;
            this.btn_3_0.UseVisualStyleBackColor = true;
            this.btn_3_0.Click += new System.EventHandler(this.col0Click);
            // 
            // btn_2_6
            // 
            this.btn_2_6.Location = new System.Drawing.Point(641, 246);
            this.btn_2_6.Name = "btn_2_6";
            this.btn_2_6.Size = new System.Drawing.Size(75, 75);
            this.btn_2_6.TabIndex = 63;
            this.btn_2_6.UseVisualStyleBackColor = true;
            this.btn_2_6.Click += new System.EventHandler(this.col6Click);
            // 
            // btn_2_5
            // 
            this.btn_2_5.Location = new System.Drawing.Point(560, 246);
            this.btn_2_5.Name = "btn_2_5";
            this.btn_2_5.Size = new System.Drawing.Size(75, 75);
            this.btn_2_5.TabIndex = 62;
            this.btn_2_5.UseVisualStyleBackColor = true;
            this.btn_2_5.Click += new System.EventHandler(this.col5Click);
            // 
            // btn_2_4
            // 
            this.btn_2_4.Location = new System.Drawing.Point(479, 246);
            this.btn_2_4.Name = "btn_2_4";
            this.btn_2_4.Size = new System.Drawing.Size(75, 75);
            this.btn_2_4.TabIndex = 61;
            this.btn_2_4.UseVisualStyleBackColor = true;
            this.btn_2_4.Click += new System.EventHandler(this.col4Click);
            // 
            // btn_2_3
            // 
            this.btn_2_3.Location = new System.Drawing.Point(398, 246);
            this.btn_2_3.Name = "btn_2_3";
            this.btn_2_3.Size = new System.Drawing.Size(75, 75);
            this.btn_2_3.TabIndex = 60;
            this.btn_2_3.UseVisualStyleBackColor = true;
            this.btn_2_3.Click += new System.EventHandler(this.col3Click);
            // 
            // btn_2_2
            // 
            this.btn_2_2.Location = new System.Drawing.Point(317, 246);
            this.btn_2_2.Name = "btn_2_2";
            this.btn_2_2.Size = new System.Drawing.Size(75, 75);
            this.btn_2_2.TabIndex = 59;
            this.btn_2_2.UseVisualStyleBackColor = true;
            this.btn_2_2.Click += new System.EventHandler(this.col2Click);
            // 
            // btn_2_1
            // 
            this.btn_2_1.Location = new System.Drawing.Point(236, 246);
            this.btn_2_1.Name = "btn_2_1";
            this.btn_2_1.Size = new System.Drawing.Size(75, 75);
            this.btn_2_1.TabIndex = 58;
            this.btn_2_1.UseVisualStyleBackColor = true;
            this.btn_2_1.Click += new System.EventHandler(this.col1Click);
            // 
            // btn_2_0
            // 
            this.btn_2_0.Location = new System.Drawing.Point(155, 246);
            this.btn_2_0.Name = "btn_2_0";
            this.btn_2_0.Size = new System.Drawing.Size(75, 75);
            this.btn_2_0.TabIndex = 57;
            this.btn_2_0.UseVisualStyleBackColor = true;
            this.btn_2_0.Click += new System.EventHandler(this.col0Click);
            // 
            // btn_1_6
            // 
            this.btn_1_6.Location = new System.Drawing.Point(641, 165);
            this.btn_1_6.Name = "btn_1_6";
            this.btn_1_6.Size = new System.Drawing.Size(75, 75);
            this.btn_1_6.TabIndex = 56;
            this.btn_1_6.UseVisualStyleBackColor = true;
            this.btn_1_6.Click += new System.EventHandler(this.col6Click);
            // 
            // btn_1_5
            // 
            this.btn_1_5.Location = new System.Drawing.Point(560, 165);
            this.btn_1_5.Name = "btn_1_5";
            this.btn_1_5.Size = new System.Drawing.Size(75, 75);
            this.btn_1_5.TabIndex = 55;
            this.btn_1_5.UseVisualStyleBackColor = true;
            this.btn_1_5.Click += new System.EventHandler(this.col5Click);
            // 
            // btn_1_4
            // 
            this.btn_1_4.Location = new System.Drawing.Point(479, 165);
            this.btn_1_4.Name = "btn_1_4";
            this.btn_1_4.Size = new System.Drawing.Size(75, 75);
            this.btn_1_4.TabIndex = 54;
            this.btn_1_4.UseVisualStyleBackColor = true;
            this.btn_1_4.Click += new System.EventHandler(this.col4Click);
            // 
            // btn_1_3
            // 
            this.btn_1_3.Location = new System.Drawing.Point(398, 165);
            this.btn_1_3.Name = "btn_1_3";
            this.btn_1_3.Size = new System.Drawing.Size(75, 75);
            this.btn_1_3.TabIndex = 53;
            this.btn_1_3.UseVisualStyleBackColor = true;
            this.btn_1_3.Click += new System.EventHandler(this.col3Click);
            // 
            // btn_1_2
            // 
            this.btn_1_2.Location = new System.Drawing.Point(317, 165);
            this.btn_1_2.Name = "btn_1_2";
            this.btn_1_2.Size = new System.Drawing.Size(75, 75);
            this.btn_1_2.TabIndex = 52;
            this.btn_1_2.UseVisualStyleBackColor = true;
            this.btn_1_2.Click += new System.EventHandler(this.col2Click);
            // 
            // btn_1_1
            // 
            this.btn_1_1.Location = new System.Drawing.Point(236, 165);
            this.btn_1_1.Name = "btn_1_1";
            this.btn_1_1.Size = new System.Drawing.Size(75, 75);
            this.btn_1_1.TabIndex = 51;
            this.btn_1_1.UseVisualStyleBackColor = true;
            this.btn_1_1.Click += new System.EventHandler(this.col1Click);
            // 
            // btn_1_0
            // 
            this.btn_1_0.Location = new System.Drawing.Point(155, 165);
            this.btn_1_0.Name = "btn_1_0";
            this.btn_1_0.Size = new System.Drawing.Size(75, 75);
            this.btn_1_0.TabIndex = 50;
            this.btn_1_0.UseVisualStyleBackColor = true;
            this.btn_1_0.Click += new System.EventHandler(this.col0Click);
            // 
            // btn_0_6
            // 
            this.btn_0_6.Location = new System.Drawing.Point(641, 84);
            this.btn_0_6.Name = "btn_0_6";
            this.btn_0_6.Size = new System.Drawing.Size(75, 75);
            this.btn_0_6.TabIndex = 49;
            this.btn_0_6.UseVisualStyleBackColor = true;
            this.btn_0_6.Click += new System.EventHandler(this.col6Click);
            // 
            // btn_0_5
            // 
            this.btn_0_5.Location = new System.Drawing.Point(560, 84);
            this.btn_0_5.Name = "btn_0_5";
            this.btn_0_5.Size = new System.Drawing.Size(75, 75);
            this.btn_0_5.TabIndex = 48;
            this.btn_0_5.UseVisualStyleBackColor = true;
            this.btn_0_5.Click += new System.EventHandler(this.col5Click);
            // 
            // btn_0_4
            // 
            this.btn_0_4.Location = new System.Drawing.Point(479, 84);
            this.btn_0_4.Name = "btn_0_4";
            this.btn_0_4.Size = new System.Drawing.Size(75, 75);
            this.btn_0_4.TabIndex = 47;
            this.btn_0_4.UseVisualStyleBackColor = true;
            this.btn_0_4.Click += new System.EventHandler(this.col4Click);
            // 
            // btn_0_3
            // 
            this.btn_0_3.Location = new System.Drawing.Point(398, 84);
            this.btn_0_3.Name = "btn_0_3";
            this.btn_0_3.Size = new System.Drawing.Size(75, 75);
            this.btn_0_3.TabIndex = 46;
            this.btn_0_3.UseVisualStyleBackColor = true;
            this.btn_0_3.Click += new System.EventHandler(this.col3Click);
            // 
            // btn_0_2
            // 
            this.btn_0_2.Location = new System.Drawing.Point(317, 84);
            this.btn_0_2.Name = "btn_0_2";
            this.btn_0_2.Size = new System.Drawing.Size(75, 75);
            this.btn_0_2.TabIndex = 45;
            this.btn_0_2.UseVisualStyleBackColor = true;
            this.btn_0_2.Click += new System.EventHandler(this.col2Click);
            // 
            // btn_0_1
            // 
            this.btn_0_1.Location = new System.Drawing.Point(236, 84);
            this.btn_0_1.Name = "btn_0_1";
            this.btn_0_1.Size = new System.Drawing.Size(75, 75);
            this.btn_0_1.TabIndex = 44;
            this.btn_0_1.UseVisualStyleBackColor = true;
            this.btn_0_1.Click += new System.EventHandler(this.col1Click);
            // 
            // btn_0_0
            // 
            this.btn_0_0.Location = new System.Drawing.Point(155, 84);
            this.btn_0_0.Name = "btn_0_0";
            this.btn_0_0.Size = new System.Drawing.Size(75, 75);
            this.btn_0_0.TabIndex = 43;
            this.btn_0_0.UseVisualStyleBackColor = true;
            this.btn_0_0.Click += new System.EventHandler(this.col0Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(879, 648);
            this.Controls.Add(this.btn_5_6);
            this.Controls.Add(this.btn_5_5);
            this.Controls.Add(this.btn_5_4);
            this.Controls.Add(this.btn_5_3);
            this.Controls.Add(this.btn_5_2);
            this.Controls.Add(this.btn_5_1);
            this.Controls.Add(this.btn_5_0);
            this.Controls.Add(this.btn_4_6);
            this.Controls.Add(this.btn_4_5);
            this.Controls.Add(this.btn_4_4);
            this.Controls.Add(this.btn_4_3);
            this.Controls.Add(this.btn_4_2);
            this.Controls.Add(this.btn_4_1);
            this.Controls.Add(this.btn_4_0);
            this.Controls.Add(this.btn_3_6);
            this.Controls.Add(this.btn_3_5);
            this.Controls.Add(this.btn_3_4);
            this.Controls.Add(this.btn_3_3);
            this.Controls.Add(this.btn_3_2);
            this.Controls.Add(this.btn_3_1);
            this.Controls.Add(this.btn_3_0);
            this.Controls.Add(this.btn_2_6);
            this.Controls.Add(this.btn_2_5);
            this.Controls.Add(this.btn_2_4);
            this.Controls.Add(this.btn_2_3);
            this.Controls.Add(this.btn_2_2);
            this.Controls.Add(this.btn_2_1);
            this.Controls.Add(this.btn_2_0);
            this.Controls.Add(this.btn_1_6);
            this.Controls.Add(this.btn_1_5);
            this.Controls.Add(this.btn_1_4);
            this.Controls.Add(this.btn_1_3);
            this.Controls.Add(this.btn_1_2);
            this.Controls.Add(this.btn_1_1);
            this.Controls.Add(this.btn_1_0);
            this.Controls.Add(this.btn_0_6);
            this.Controls.Add(this.btn_0_5);
            this.Controls.Add(this.btn_0_4);
            this.Controls.Add(this.btn_0_3);
            this.Controls.Add(this.btn_0_2);
            this.Controls.Add(this.btn_0_1);
            this.Controls.Add(this.btn_0_0);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_5_6;
        private System.Windows.Forms.Button btn_5_5;
        private System.Windows.Forms.Button btn_5_4;
        private System.Windows.Forms.Button btn_5_3;
        private System.Windows.Forms.Button btn_5_2;
        private System.Windows.Forms.Button btn_5_1;
        private System.Windows.Forms.Button btn_5_0;
        private System.Windows.Forms.Button btn_4_6;
        private System.Windows.Forms.Button btn_4_5;
        private System.Windows.Forms.Button btn_4_4;
        private System.Windows.Forms.Button btn_4_3;
        private System.Windows.Forms.Button btn_4_2;
        private System.Windows.Forms.Button btn_4_1;
        private System.Windows.Forms.Button btn_4_0;
        private System.Windows.Forms.Button btn_3_6;
        private System.Windows.Forms.Button btn_3_5;
        private System.Windows.Forms.Button btn_3_4;
        private System.Windows.Forms.Button btn_3_3;
        private System.Windows.Forms.Button btn_3_2;
        private System.Windows.Forms.Button btn_3_1;
        private System.Windows.Forms.Button btn_3_0;
        private System.Windows.Forms.Button btn_2_6;
        private System.Windows.Forms.Button btn_2_5;
        private System.Windows.Forms.Button btn_2_4;
        private System.Windows.Forms.Button btn_2_3;
        private System.Windows.Forms.Button btn_2_2;
        private System.Windows.Forms.Button btn_2_1;
        private System.Windows.Forms.Button btn_2_0;
        private System.Windows.Forms.Button btn_1_6;
        private System.Windows.Forms.Button btn_1_5;
        private System.Windows.Forms.Button btn_1_4;
        private System.Windows.Forms.Button btn_1_3;
        private System.Windows.Forms.Button btn_1_2;
        private System.Windows.Forms.Button btn_1_1;
        private System.Windows.Forms.Button btn_1_0;
        private System.Windows.Forms.Button btn_0_6;
        private System.Windows.Forms.Button btn_0_5;
        private System.Windows.Forms.Button btn_0_4;
        private System.Windows.Forms.Button btn_0_3;
        private System.Windows.Forms.Button btn_0_2;
        private System.Windows.Forms.Button btn_0_1;
        private System.Windows.Forms.Button btn_0_0;
    }
}