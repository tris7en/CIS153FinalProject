﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CIS153_GitHubExample
{
    public partial class BlueWin : Form
    {
        Form formblue;
        public BlueWin()
        {
            InitializeComponent();
            this.WindowState = FormWindowState.Maximized;
        }

        public BlueWin(Form2 BlueWin)
        {
            InitializeComponent();
            this.WindowState = FormWindowState.Maximized;
            formblue = BlueWin;
        }
        public void formPassedToMe(Form2 BlueWin)
        {
            formblue = BlueWin;
        }

        public BlueWin(_1Player BlueWin)
        {
            InitializeComponent();
            this.WindowState = FormWindowState.Maximized;
            formblue = BlueWin;
        }
        public void formPassedToMe(_1Player BlueWin)
        {
            formblue = BlueWin;
        }


        private void btn_Menu_Click(object sender, EventArgs e)
        {

        }

        private void btn_Stats_Click(object sender, EventArgs e)
        {

        }

        private void btn_Exit_Click(object sender, EventArgs e)
        {
            System.Environment.Exit(0);
        }
    }
}
