﻿
namespace CIS153_GitHubExample
{
    partial class BlueWin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BlueWin));
            this.btn_Exit = new System.Windows.Forms.Button();
            this.BlueWon = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.BlueWon)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_Exit
            // 
            this.btn_Exit.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_Exit.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_Exit.BackgroundImage")));
            this.btn_Exit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_Exit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Exit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Exit.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btn_Exit.Location = new System.Drawing.Point(679, 813);
            this.btn_Exit.Name = "btn_Exit";
            this.btn_Exit.Size = new System.Drawing.Size(322, 135);
            this.btn_Exit.TabIndex = 8;
            this.btn_Exit.UseVisualStyleBackColor = true;
            this.btn_Exit.Click += new System.EventHandler(this.btn_Exit_Click);
            // 
            // BlueWon
            // 
            this.BlueWon.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.BlueWon.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("BlueWon.BackgroundImage")));
            this.BlueWon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BlueWon.Location = new System.Drawing.Point(394, 71);
            this.BlueWon.Name = "BlueWon";
            this.BlueWon.Size = new System.Drawing.Size(860, 362);
            this.BlueWon.TabIndex = 9;
            this.BlueWon.TabStop = false;
            // 
            // BlueWin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.HotTrack;
            this.ClientSize = new System.Drawing.Size(1636, 960);
            this.Controls.Add(this.BlueWon);
            this.Controls.Add(this.btn_Exit);
            this.Name = "BlueWin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form3";
            ((System.ComponentModel.ISupportInitialize)(this.BlueWon)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button btn_Exit;
        private System.Windows.Forms.PictureBox BlueWon;
    }
}